import path from 'path'
import { defineConfig, loadEnv } from 'vite'
import Vue from '@vitejs/plugin-vue'
import Unocss from 'unocss/vite'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { NaiveUiResolver } from 'unplugin-vue-components/resolvers'
import simpleHtmlPlugin from 'vite-plugin-simple-html'
import { pluginIcons } from './build/custom-plugin'

export default defineConfig(({ command, mode }) => {
  // vite build 构建
  const isBuild = command === 'build'
  // process.cwd()项目根目录，根据mode加载环境变量, mode: development/production
  const viteEnv = loadEnv(mode, process.cwd())
  const { VITE_TITLE, VITE_PUBLIC_PATH, VITE_PROXY_TARGET, VITE_BASE_API } = viteEnv

  return {
    base: VITE_PUBLIC_PATH || '/',
    plugins: [
      Vue(), // 提供 Vue 3 单文件组件支持
      Unocss(), // 提供unoCss支持，配置文件：uno.config.js
      AutoImport({
        imports: ['vue', 'vue-router'],
        dts: false, // 不生成auto-imports.d.ts
      }),
      Components({
        // 自动引入NaiveUi组件
        resolvers: [NaiveUiResolver()],
        dts: false,
      }),
      simpleHtmlPlugin({
        minify: isBuild,
        inject: {
          // index.html 注入数据
          data: {
            title: VITE_TITLE,
          },
        },
      }),
      // 自定义插件，用于生成自定义icon，并添加到虚拟模块
      pluginIcons(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(process.cwd(), 'src'),
        '~': path.resolve(process.cwd()),
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3200,
      open: false,
      proxy: {
        [VITE_BASE_API]: {
          target: VITE_PROXY_TARGET,
          changeOrigin: true,
          rewrite: (path) => path.replace(new RegExp(`^${VITE_BASE_API}`), ''),
          secure: false,
          configure: (proxy, options) => {
            // 配置此项可在响应头中看到请求的真实地址
            proxy.on('proxyRes', (proxyRes, req) => {
              proxyRes.headers['x-real-url'] = new URL(req.url || '', options.target)?.href || ''
            })
          },
        },
      },
    },
    build: {
      chunkSizeWarningLimit: 1024, // chunk 大小警告的限制（单位kb）
    },
  }
})
