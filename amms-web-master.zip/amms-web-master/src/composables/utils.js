export const trim = (value = '') => {
  return !value.startsWith(' ') && !value.endsWith(' ')
}
