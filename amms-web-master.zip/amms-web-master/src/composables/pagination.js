export const getPagination = (options = {}) => {
  const pagination = reactive({
    page: 1, // 当前页面
    pageSize: 10, // 每页显示几条
    itemCount: 0, // 总数
    showSizePicker: true, // 是否显示页数大小选择
    pageSizes: [10, 20, 50],
    prefix({ itemCount }) {
      return `总数: ${itemCount}`
    },
    onUpdatePage(page) {
      pagination.page = page
      pagination.change({
        type: 'page',
        value: page,
      })
    },
    onUpdatePageSize(size) {
      pagination.pageSize = size
      pagination.page = 1
      pagination.change({
        type: 'size',
        value: size,
      })
    },
    change() {},
    ...options,
  })
  return pagination
}
