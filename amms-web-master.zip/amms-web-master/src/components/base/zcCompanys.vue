<template>
  <div>
    <n-tree
      default-expand-all
      block-line
      show-line
      :data="deptList"
      key-field="id"
      label-field="label"
      selectable
      :node-props="nodeProps"
      :selected-keys="selectedKeys"
    />
  </div>
</template>
<script setup>
import { getDeptTree } from '@/api/dept'
const emit = defineEmits(['selected'])
const props = defineProps({
  selectedKey: {
    type: [String, Number],
    default: null,
  },
})
// 选择节点
const selectedKeys = ref([])
watch(
  () => props.selectedKey,
  (key) => {
    if (key) {
      selectedKeys.value = [key]
    } else {
      selectedKeys.value = []
    }
  },
  {
    immediate: true,
  }
)

// 节点事件
const nodeProps = ({ option }) => {
  return {
    onClick() {
      selectedKeys.value = [option.id]
      emit('selected', option)
    },
  }
}

// 定义获取部门组织数
const deptList = ref([])
const getDeptTreeData = () => {
  getDeptTree().then(({ data }) => {
    deptList.value = data || []
  })
}
getDeptTreeData()
</script>
