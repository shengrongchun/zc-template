export { default as zcCompanys } from './zcCompanys.vue'
