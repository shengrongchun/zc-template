<template>
  <AppCard bordered bg="#fafafc dark:black" class="mb-30 min-h-60 rounded-4">
    <form class="flex justify-between p-16" @submit.prevent="handleSubmit()">
      <n-space wrap :size="[32, 16]">
        <slot />
      </n-space>
      <div class="flex-shrink-0">
        <slot name="tools" />
      </div>
    </form>
  </AppCard>
</template>
<script setup>
const emit = defineEmits(['handleSubmit'])
const handleSubmit = () => {
  emit('handleSubmit')
}
</script>
