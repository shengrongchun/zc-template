<template>
  <div class="h-40 w-40 rounded-full bg-primary p-1/100">
    <img src="@/assets/images/logo.png" alt="Logo" />
  </div>
</template>
