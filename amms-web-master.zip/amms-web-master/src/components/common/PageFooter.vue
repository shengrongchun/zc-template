<template>
  <footer class="f-c-c text-14 text-gray-500">
    <p>Copyright © 2024 Zheng Cang</p>
  </footer>
</template>
