import { resolveResError } from './helpers'
import { useAuthStore } from '@/store'
import { tansParams } from '@/utils'

export function setupInterceptors(axiosInstance) {
  function reqResolve(config) {
    $loadingBar.start()

    // get请求映射params参数
    if (config.method === 'get' && config.params) {
      let url = config.url + '?' + tansParams(config.params)
      url = url.slice(0, -1)
      config.params = {}
      config.url = url
    }

    // 处理不需要token的请求
    if (config.noNeedToken) {
      return config
    }

    const { accessToken } = useAuthStore()
    if (accessToken) {
      // token: Bearer + xxx
      config.headers.Authorization = 'Bearer ' + accessToken
    }

    return config
  }

  function reqReject(error) {
    $loadingBar.error()
    return Promise.reject(error)
  }

  const SUCCESS_CODES = [0, 200]
  function resResolve(response) {
    $loadingBar.finish()
    const { data, status, config, statusText, headers } = response
    if (headers['content-type']?.includes('json')) {
      if (SUCCESS_CODES.includes(data?.code)) {
        return Promise.resolve(data)
      }
      const code = data?.code ?? status
      // 根据code处理对应的操作，并返回处理后的message
      const message = resolveResError(code, data?.msg ?? data?.message ?? statusText)

      //需要错误提醒
      !config?.noNeedTip && message && window.$message?.error(message)
      return Promise.reject({ code, message, error: data ?? response })
    }
    return Promise.resolve(data ?? response)
  }

  async function resReject(error) {
    $loadingBar.error()
    if (!error || !error.response) {
      const code = error?.code
      /** 根据code处理对应的操作，并返回处理后的message */
      const message = resolveResError(code, error.msg ?? error.message)
      window.$message?.error(message)
      return Promise.reject({ code, message, error })
    }

    const { data, status, config } = error.response
    const code = data?.code ?? status

    const message = resolveResError(code, data?.message ?? error.message)
    /** 需要错误提醒 */
    !config?.noNeedTip && message && window.$message?.error(message)
    return Promise.reject({ code, message, error: error.response?.data || error.response })
  }

  axiosInstance.interceptors.request.use(reqResolve, reqReject)
  axiosInstance.interceptors.response.use(resResolve, resReject)
}
