import axios from 'axios'
import { setupInterceptors } from './interceptors'

const { VITE_BASE_API } = import.meta.env
export function createAxios(options = {}) {
  const defaultOptions = {
    baseURL: VITE_BASE_API,
    timeout: 12000,
  }
  const service = axios.create({
    ...defaultOptions,
    ...options,
  })
  // 设置拦截器
  setupInterceptors(service)
  return service
}

export const request = createAxios()
