<template>
  <div class="flex flex-shrink-0 items-center px-12 text-18">
    <i
      class="mr-16 cursor-pointer"
      :class="isDark ? 'i-zc:moon' : 'i-zc:sun'"
      @click="toggleDark"
    />
    <i
      class="mr-16 cursor-pointer"
      :class="isFullscreen ? 'i-zc:minimize' : 'i-zc:maximize'"
      @click="toggle"
    />
    <UserAvatar />
  </div>
</template>

<script setup>
import { UserAvatar } from '@/layouts/components'
import { useDark, useToggle, useFullscreen } from '@vueuse/core'
import { useAppStore } from '@/store'

const appStore = useAppStore()
const isDark = useDark()
const toggleDark = () => {
  appStore.toggleDark()
  useToggle(isDark)()
}

const { isFullscreen, toggle } = useFullscreen()
</script>
