<template>
  <n-dropdown :options="options" @select="handleSelect">
    <div class="flex cursor-pointer items-center">
      <n-avatar round :size="36" :src="userStore.avatar" :style="avatarStyle">
        <template #default>
          <span class="m-auto">{{ userStore.nickName?.charAt(0).toUpperCase() }}</span>
        </template>
      </n-avatar>
      <div v-if="userStore.userInfo" class="ml-12 flex-col flex-shrink-0 items-center">
        <span class="text-14">{{ name }}</span>
        <span class="text-12 opacity-50">[{{ userStore.roleName }}]</span>
      </div>
    </div>
  </n-dropdown>
</template>

<script setup>
import { useUserStore, useAuthStore } from '@/store'
import { logout } from '@/api/login'

const router = useRouter()
const userStore = useUserStore()
const authStore = useAuthStore()

const name = computed(() => {
  return userStore.nickName ?? userStore.userName ?? ''
})

const generateRandomHexColor = () => {
  // 生成一个随机数，并转换成16进制字符串
  const hex = Math.floor(Math.random() * 0xffffff).toString(16)
  // 确保六位数长度
  return '#' + ('000000' + hex).slice(-6)
}
const avatarStyle = {
  color: '#fff',
  backgroundColor: generateRandomHexColor(),
}
userStore.setAvatarStyle(avatarStyle)

const options = reactive([
  {
    label: '个人资料',
    key: 'profile',
    icon: () => h('i', { class: 'i-material-symbols:person-outline text-14' }),
  },
  {
    label: '退出登录',
    key: 'logout',
    icon: () => h('i', { class: 'i-mdi:exit-to-app text-14' }),
  },
])

function handleSelect(key) {
  switch (key) {
    case 'profile':
      router.push('/profile')
      break
    case 'logout':
      $dialog.confirm({
        title: '提示',
        type: 'warning',
        content: '确认退出？',
        async confirm() {
          try {
            await logout()
          } catch (error) {
            $message.error(error)
          }
          authStore.logout()
          $message.success('已退出登录')
        },
      })
      break
  }
}
</script>
