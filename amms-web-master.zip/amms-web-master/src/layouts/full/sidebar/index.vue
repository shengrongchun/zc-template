<template>
  <SideLogo border-b="1px solid light_border dark:dark_border" />
  <SideMenu class="cus-scroll-y mt-4 h-0 flex-1" />
</template>

<script setup>
import { SideLogo, SideMenu } from '@/layouts/components'
</script>
