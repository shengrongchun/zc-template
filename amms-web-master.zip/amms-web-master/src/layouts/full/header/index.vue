<template>
  <AppCard class="flex items-center px-12" border-b="1px solid light_border dark:dark_border">
    <MenuCollapse />

    <BreadCrumb />

    <AppTools class="ml-auto" />
  </AppCard>
</template>

<script setup>
import { MenuCollapse, BreadCrumb, AppTools } from '@/layouts/components'
</script>
