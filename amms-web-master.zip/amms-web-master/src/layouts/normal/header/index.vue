<template>
  <AppCard class="flex items-center px-12" border-b="1px solid light_border dark:dark_border">
    <MenuCollapse />

    <AppTab class="w-0 flex-1 px-12" />

    <span class="mx-6 opacity-20">|</span>

    <AppTools />
  </AppCard>
</template>

<script setup>
import { MenuCollapse, AppTab, AppTools } from '@/layouts/components'
</script>
