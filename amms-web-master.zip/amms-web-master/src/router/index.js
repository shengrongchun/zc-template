import { createRouter, createWebHistory, createWebHashHistory } from 'vue-router'
import { setupRouterGuards } from './guards'
import { useAuthStore, usePermissionStore, useUserStore } from '@/store'
import { getUserInfo } from '@/store/helper'
import { basicRoutes } from './routes/basic-routes'
import { routes } from './routes'
import { getRoleMenuIds } from '@/api/role'

export const router = createRouter({
  history:
    import.meta.env.VITE_USE_HASH === 'true'
      ? createWebHashHistory(import.meta.env.VITE_PUBLIC_PATH || '/')
      : createWebHistory(import.meta.env.VITE_PUBLIC_PATH || '/'),
  routes: basicRoutes,
  scrollBehavior: () => ({ left: 0, top: 0 }),
})

export async function setupRouter(app) {
  try {
    await initUser()
  } catch (error) {
    $message.error('🚀 初始化失败', error)
  }
  // 路由守卫
  setupRouterGuards(router)
  app.use(router)
}

export async function initUser() {
  // 用户信息
  const userStore = useUserStore()
  // 登录凭证信息
  const authStore = useAuthStore()
  // 菜单，路由权限控制
  const permissionStore = usePermissionStore()

  if (!authStore.accessToken) {
    const route = unref(router.currentRoute)
    if (route.path !== '/login') {
      router.replace({
        path: '/login',
        query: route.query,
      })
    }
    return
  }
  // 每次刷新页面，不管有没有用户信息，都再一次请求更新用户信息
  const [user] = await Promise.all([getUserInfo()])
  const checkedKeysRes = []
  let isAdmin = false
  for (const role of user.roles) {
    const { roleId, roleKey } = role
    if (roleKey === 'admin') {
      isAdmin = true
      continue
    }
    checkedKeysRes.push(getRoleMenuIds(roleId))
  }
  let checkedKeys = null
  if (!isAdmin) {
    ;[...checkedKeys] = await Promise.all(checkedKeysRes)
    checkedKeys = checkedKeys.map(({ checkedKeys }) => checkedKeys).flat(1)
  }
  userStore.setUser(user)
  // 通过 routes 创建路由
  permissionStore.setPermissions(JSON.parse(JSON.stringify(routes)), checkedKeys)
  const routeComponents = import.meta.glob('@/views/**/*.vue')
  permissionStore.accessRoutes.forEach((route) => {
    route.component = routeComponents[route.component] || undefined
    !router.hasRoute(route.name) && router.addRoute(route)
  })
}
