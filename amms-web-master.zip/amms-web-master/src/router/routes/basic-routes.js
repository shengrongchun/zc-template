export const basicRoutes = [
  {
    name: 'Login',
    path: '/login',
    component: () => import('@/views/common/login/index.vue'),
    meta: {
      title: '登录页',
      layout: 'empty',
    },
  },

  {
    name: 'Home',
    path: '/',
    component: () => import('@/views/common/home/index.vue'),
    meta: {
      title: '首页',
    },
  },

  {
    name: '404',
    path: '/404',
    component: () => import('@/views/common/error-page/404.vue'),
    meta: {
      title: '页面飞走了',
      layout: 'empty',
    },
  },

  {
    name: '403',
    path: '/403',
    component: () => import('@/views/common/error-page/403.vue'),
    meta: {
      title: '没有权限',
      layout: 'empty',
    },
  },

  {
    name: 'UserProfile',
    path: '/profile',
    component: () => import('@/views/common/profile/index.vue'),
    meta: {
      title: '个人资料',
      layout: null,
    },
  },
]
