//
import systemRoutes from './system'
export const routes = [
  {
    name: 'Base',
    path: '',
    redirect: null,
    component: null,
    meta: {
      icon: 'i-zc:grid',
      title: '基础功能',
      key: 1, // 权限控制key,必填，唯一
      layout: '',
      keepAlive: false,
      parentKey: null,
      btns: [], // 当前路由下：哪些按钮是可以显示的
    },
    children: [
      {
        name: 'Icon',
        path: '/base/icon',
        redirect: null,
        component: '/src/views/base/unocss-icon.vue',
        meta: {
          icon: 'i-zc:feather',
          title: '图标 Icon',
          layout: '',
          keepAlive: false,
          parentKey: null,
          key: 2,
        },
      },
      {
        name: 'BaseComponents',
        path: '/base/components',
        redirect: null,
        component: '/src/views/base/index.vue',
        meta: {
          icon: 'i-zc:awesome',
          title: '基础组件',
          layout: null,
          keepAlive: false,
          parentKey: null,
          key: 3,
        },
      },
      {
        name: 'BaseTable',
        path: '/base/table',
        redirect: null,
        component: '/src/views/base/table.vue',
        meta: {
          icon: 'i-zc:table',
          title: '表格组件',
          layout: null,
          keepAlive: false,
          parentKey: null,
          key: 4,
        },
      },
    ],
  },
  ...systemRoutes,
]
