import { router } from '@/router'
import { initDrag } from './utils'

const permission = {
  mounted(el, binding) {
    const currentRoute = unref(router.currentRoute)
    const btns = currentRoute.meta?.btns?.map((item) => item.code) || []
    if (!btns.includes(binding.value)) {
      el.remove()
    }
  },
}

const modalMove = {
  updated(el, binding) {
    if (binding.value) {
      nextTick(() => {
        const cardHeaderList = document.querySelectorAll('.modal-move .n-card-header__main')
        const dialogHeaderList = document.querySelectorAll('.modal-move .n-dialog__title')
        initDrag(
          Array.prototype.at.call(cardHeaderList.length ? cardHeaderList : dialogHeaderList, -1),
          Array.prototype.at.call(document.querySelectorAll('.modal-move'), -1)
        )
      })
    }
  },
}
export function setupDirectives(app) {
  app.directive('permission', permission)
  app.directive('modalMove', modalMove)
}
