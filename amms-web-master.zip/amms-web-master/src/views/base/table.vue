<template>
  <CommonPage>
    <template #action>
      <n-button type="primary">
        <i class="i-material-symbols:add mr-4 text-18" />
        创建新用户
      </n-button>
    </template>
    <PageHeader @handle-submit="headerSubmit">
      <PageHeaderItem label="用户名" :label-width="50">
        <n-input
          v-model:value="queryItems.username"
          type="text"
          placeholder="请输入用户名"
          clearable
        />
      </PageHeaderItem>

      <PageHeaderItem label="性别" :label-width="50">
        <n-select v-model:value="queryItems.gender" clearable :options="genders" />
      </PageHeaderItem>

      <PageHeaderItem label="状态" :label-width="50">
        <n-select
          v-model:value="queryItems.enable"
          clearable
          :options="[
            { label: '启用', value: 1 },
            { label: '停用', value: 0 },
          ]"
        />
      </PageHeaderItem>
      <template #tools>
        <n-button ghost type="primary">
          <i class="i-zc:rotate-ccw mr-4" />
          重置
        </n-button>
        <n-button attr-type="submit" class="ml-20" type="primary">
          <i class="i-zc:search mr-4" />
          搜索
        </n-button>
      </template>
    </PageHeader>
    <!-- 表格加分页 -->
    <n-data-table :columns="columns" :data="tableData" :pagination="true" />
  </CommonPage>
</template>
<script setup>
import { NButton } from 'naive-ui'
const headerSubmit = () => {}
const queryItems = ref({})
const genders = [
  { label: '男', value: '0' },
  { label: '女', value: '1' },
]
const columns = [
  {
    title: '用户名',
    key: 'name',
  },
  {
    title: '年纪',
    key: 'age',
  },
  {
    title: '地址',
    key: 'address',
  },
  {
    title: '标签',
    key: 'tags',
  },
  {
    title: '操作',
    key: 'actions',
    render() {
      return h(
        NButton,
        {
          size: 'small',
          type: 'primary',
        },
        { default: () => '编辑' }
      )
    },
  },
]
const tableData = [
  {
    key: 0,
    name: 'John Brown',
    age: 32,
    address: 'New York No. 1 Lake Park',
    tags: ['nice', 'developer'],
  },
  {
    key: 1,
    name: 'Jim Green',
    age: 42,
    address: 'London No. 1 Lake Park',
    tags: ['wow'],
  },
  {
    key: 2,
    name: 'Joe Black',
    age: 32,
    address: 'Sidney No. 1 Lake Park',
    tags: ['cool', 'teacher'],
  },
]
</script>
