<template>
  <AppPage show-footer>
    <n-card>
      <n-space align="center">
        <n-avatar round :size="100" :src="userStore.avatar" :style="userStore.avatarStyle">
          <template #default>
            <span class="m-auto">{{ userStore.nickName?.charAt(0).toUpperCase() }}</span>
          </template>
        </n-avatar>
        <div class="ml-20">
          <div class="flex items-center text-16">
            <span>用户名:</span>
            <span class="ml-12 opacity-80">{{ name }}</span>
            <n-button class="ml-32" type="primary" text @click="showPwdModal = true">
              <i class="i-zc:edit mr-4" />
              修改密码
            </n-button>
          </div>
          <div class="mt-16 flex items-center">
            <n-button type="primary" ghost>更改头像</n-button>
          </div>
        </div>
      </n-space>
    </n-card>
    <n-card class="mt-20" title="个人资料信息">
      <template #header-extra>
        <n-button type="primary" text @click="showUserModal = true">
          <i class="i-zc:edit mr-4" />
          修改资料
        </n-button>
      </template>

      <n-descriptions
        label-placement="left"
        :label-style="{ width: '200px', textAlign: 'center' }"
        :column="2"
        bordered
      >
        <n-descriptions-item label="用户昵称">{{ userStore.nickName }}</n-descriptions-item>
        <n-descriptions-item label="用户名称">{{ userStore.userName }}</n-descriptions-item>
        <n-descriptions-item label="手机号码">{{ userStore.phonenumber }}</n-descriptions-item>
        <n-descriptions-item label="性别">
          {{
            sexOptions.find((item) => item.value === userStore.userInfo?.gender)?.label ?? '未知'
          }}
        </n-descriptions-item>
        <n-descriptions-item label="邮箱">{{ userStore.userInfo?.email }}</n-descriptions-item>
        <n-descriptions-item label="所属角色">
          {{ userStore.userInfo?.roleName }}
        </n-descriptions-item>
      </n-descriptions>
    </n-card>
    <!-- 密码修改弹框 -->
    <template v-modal-move="showPwdModal">
      <n-modal
        v-model:show="showPwdModal"
        title="修改密码"
        :style="{ width: '420px' }"
        preset="card"
        :mask-closable="false"
        class="modal-move"
      >
        <!-- 内容 -->
        <n-form
          ref="pwdFormRef"
          :model="pwdForm"
          label-placement="left"
          require-mark-placement="left"
        >
          <n-form-item label="原密码" path="oldPassword" :rule="[required, ...pwdRequired]">
            <n-input
              v-model:value="pwdForm.oldPassword"
              type="password"
              placeholder="请输入原密码"
              show-password-on="mousedown"
            />
          </n-form-item>
          <n-form-item label="新密码" path="newPassword" :rule="[required, ...pwdRequired]">
            <n-input
              v-model:value="pwdForm.newPassword"
              type="password"
              placeholder="请输入新密码"
              show-password-on="mousedown"
            />
          </n-form-item>
          <n-form-item label="再确认" path="againNewPassword" :rule="[required, ...pwdRequired]">
            <n-input
              v-model:value="pwdForm.againNewPassword"
              type="password"
              placeholder="请再次输入新密码"
              show-password-on="mousedown"
            />
          </n-form-item>
        </n-form>
        <!-- 底部按钮 -->
        <template #footer>
          <footer class="flex justify-end">
            <n-button @click="showPwdModal = false">取消</n-button>
            <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmPwd">
              确定
            </n-button>
          </footer>
        </template>
      </n-modal>
    </template>
    <!-- 个人信息修改弹框 -->
    <template v-modal-move="showUserModal">
      <n-modal
        v-model:show="showUserModal"
        class="modal-move"
        title="修改资料"
        :style="{ width: '420px' }"
        preset="card"
        :mask-closable="false"
      >
        <!-- 内容 -->
        <n-form
          ref="userFormRef"
          :model="userForm"
          label-placement="left"
          require-mark-placement="left"
          label-width="80"
        >
          <n-form-item label="昵称" path="nickName" :rule="required">
            <n-input
              v-model:value="userForm.nickName"
              placeholder="请输入昵称"
              :allow-input="trim"
            />
          </n-form-item>
          <n-form-item label="性别" path="sex" :rule="required">
            <n-select v-model:value="userForm.sex" :options="sexOptions" placeholder="请选择性别" />
          </n-form-item>
          <n-form-item label="手机号码" path="phonenumber" :rule="[required, ...phoneRequired]">
            <n-input
              v-model:value="userForm.phonenumber"
              placeholder="请输入手机号码"
              :allow-input="trim"
            />
          </n-form-item>
          <n-form-item label="邮箱" path="email" :rule="[required, ...emailRequired]">
            <n-input v-model:value="userForm.email" placeholder="请输入邮箱" :allow-input="trim" />
          </n-form-item>
        </n-form>
        <!-- 底部按钮 -->
        <template #footer>
          <footer class="flex justify-end">
            <n-button @click="showUserModal = false">取消</n-button>
            <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmUser">
              确定
            </n-button>
          </footer>
        </template>
      </n-modal>
    </template>
  </AppPage>
</template>

<script setup>
import { useUserStore } from '@/store'
import { changePassword, updateProfile } from '@/api/user'
import { getUserInfo } from '@/store/helper'
import { trim } from '@/composables'
import { sexOptions, required, pwdRequired, emailRequired, phoneRequired } from '@/store/options'

const userStore = useUserStore()
const name = computed(() => {
  return userStore.userName ?? userStore.nickName ?? ''
})

// loading
const loading = ref(false)
// 修改密码
const pwdFormRef = ref(null)
const showPwdModal = ref(false)

const pwdForm = ref({
  oldPassword: null,
  newPassword: null,
  againNewPassword: null,
})
const confirmPwd = () => {
  pwdFormRef.value
    ?.validate((error) => {
      if (!error) {
        const { oldPassword, newPassword, againNewPassword } = pwdForm.value
        if (newPassword !== againNewPassword) {
          $message.error('两次密码输入不一致')
          return
        }
        loading.value = true
        changePassword({
          oldPassword,
          newPassword,
        })
          .then(() => {
            showPwdModal.value = false
            refreshUserInfo()
            $message.success('修改密码成功')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}
// 修改个人信息
const userFormRef = ref(null)
const showUserModal = ref(false)

const userForm = ref({
  email: userStore.userInfo?.email,
  nickName: userStore.nickName,
  sex: userStore.userInfo?.gender,
  phonenumber: userStore.phonenumber,
})

const confirmUser = () => {
  userFormRef.value
    ?.validate((error) => {
      if (!error) {
        loading.value = true
        updateProfile(userForm.value)
          .then(() => {
            showUserModal.value = false
            refreshUserInfo()
            $message.success('修改资料成功')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}

async function refreshUserInfo() {
  const user = await getUserInfo()
  userStore.setUser(user)
}
</script>
