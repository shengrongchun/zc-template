import { NButton, NTag } from 'naive-ui'
import { statusOptions } from '@/store/options'

export const createColumns = ({ addPost, delPost }) => {
  return [
    {
      title: '岗位编号',
      key: 'postId',
    },
    {
      title: '岗位编码',
      key: 'postCode',
    },
    {
      title: '岗位名称',
      key: 'postName',
    },
    {
      title: '岗位排序',
      key: 'postSort',
    },
    {
      title: '状态',
      key: 'status',
      render(row) {
        return h(
          NTag,
          {
            type: row.status === '0' ? 'success' : 'error',
            bordered: false,
          },
          { default: () => statusOptions.find(({ value }) => value === row.status).label }
        )
      },
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'actions',
      render(row) {
        return [
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              onClick: () => addPost(row),
            },
            { default: () => '编辑' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'error',
              style: {
                marginLeft: '10px',
              },
              onClick: () => delPost(row),
            },
            { default: () => '删除' }
          ),
        ]
      },
    },
  ]
}
