<template>
  <template v-modal-move="showUserModal">
    <n-modal
      v-model:show="showUserModal"
      class="modal-move"
      :title="title"
      :style="{ width: '50%' }"
      preset="card"
      :mask-closable="false"
    >
      <!-- 内容 -->
      <n-form
        ref="userFormRef"
        :model="userForm"
        label-placement="left"
        require-mark-placement="left"
        label-width="80"
      >
        <n-row>
          <n-col :span="12">
            <n-form-item label="岗位名称" path="postName" :rule="required">
              <n-input
                v-model:value="userForm.postName"
                placeholder="请输入岗位名称"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="岗位编码" path="postCode" :rule="required">
              <n-input
                v-model:value="userForm.postCode"
                placeholder="请输入岗位编码"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="岗位顺序" path="postSort" :rule="{ ...required, type: 'number' }">
              <n-input-number v-model:value="userForm.postSort" clearable class="w-100%" />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="状态" path="status" :rule="required">
              <n-radio-group v-model:value="userForm.status">
                <n-space>
                  <n-radio value="0">启用</n-radio>
                  <n-radio value="1">停用</n-radio>
                </n-space>
              </n-radio-group>
            </n-form-item>
          </n-col>
        </n-row>

        <n-form-item label="备注" path="remark">
          <n-input
            v-model:value="userForm.remark"
            type="textarea"
            placeholder="请输入内容"
            clearable
          />
        </n-form-item>
      </n-form>
      <!-- 底部按钮 -->
      <template #footer>
        <footer class="flex justify-end">
          <n-button @click="showUserModal = false">取消</n-button>
          <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmUser">
            确定
          </n-button>
        </footer>
      </template>
    </n-modal>
  </template>
</template>
<script setup>
import { required } from '@/store/options'
import { trim } from '@/composables'
import { updatePost } from '@/api/post'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showUserModal = ref(false)
const userForm = ref({})
const loading = ref(false)

watch(
  () => props.show,
  (value) => {
    showUserModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showUserModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    userForm.value = data
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  return userForm.value.postId !== undefined ? '编辑岗位' : '新增岗位'
})

// 确定修改或者添加岗位
const userFormRef = ref(null)
const confirmUser = () => {
  userFormRef.value
    ?.validate((error) => {
      if (!error) {
        loading.value = true
        updatePost(userForm.value)
          .then(() => {
            showUserModal.value = false
            $message.success('操作成功')
            emits('confirm')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}
</script>
