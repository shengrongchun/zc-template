<template>
  <CommonPage>
    <template #action>
      <div class="flex">
        <n-button ghost type="primary" class="ml-20" @click="reset">
          <i class="i-zc:rotate-ccw mr-4" />
          重置
        </n-button>
        <n-button class="ml-20" type="primary" @click="search">
          <i class="i-zc:search mr-4" />
          查询
        </n-button>
        <n-button type="primary" class="ml-20" @click="addPost()">
          <i class="i-zc:plus mr-4" />
          新建
        </n-button>
        <n-button type="default" class="ml-20" @click="download">
          <i class="i-zc:download mr-4" />
          导出
        </n-button>
      </div>
    </template>
    <div>
      <PageHeader>
        <PageHeaderItem label="岗位编码" :label-width="70">
          <n-input
            v-model:value="searchForm.postCode"
            type="text"
            placeholder="岗位编码模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="岗位名称" :label-width="70">
          <n-input
            v-model:value="searchForm.postName"
            type="text"
            placeholder="岗位名称模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="状态" :label-width="70">
          <n-select v-model:value="searchForm.status" clearable :options="statusOptions" />
        </PageHeaderItem>
      </PageHeader>
      <!-- 表格加分页 -->
      <n-data-table
        :remote="true"
        :loading="loading"
        :columns="columns"
        :data="tableData"
        :pagination="pagination"
      />
    </div>
    <!-- 新增/修改 -->
    <AddDialog
      :show="showDialog"
      :data="postData"
      @confirm="search"
      @close="showDialog = false"
    ></AddDialog>
  </CommonPage>
</template>
<script setup>
import { getPostList, deletePost } from '@/api/post'
import { statusOptions } from '@/store/options'
import { getPagination } from '@/composables'
import { downloadFile } from '@/utils'
import { createColumns } from './options'
import AddDialog from './addPost.vue'

// 表格数据
const tableData = ref([])
// 加载loading
const loading = ref(false)
// 分页数据
const pagination = getPagination({
  change() {
    search()
  },
})
// 初始化form数据
const form = {
  postCode: null, // 岗位编码
  postName: null, // 岗位名称
  status: null, // 状态
}
const searchForm = ref(JSON.parse(JSON.stringify(form)))
// 重置查询条件
const reset = () => {
  searchForm.value = JSON.parse(JSON.stringify(form))
  pagination.page = 1
  pagination.pageSize = 10
  search()
}
// 获取查询参数
const getParams = () => {
  const { page: pageNum, pageSize } = pagination
  const { postCode, postName, status } = searchForm.value
  const params = {
    postCode,
    postName,
    status,
    pageNum,
    pageSize,
  }
  return params
}
// 查询数据
const search = () => {
  loading.value = true
  const params = getParams()
  getPostList(params)
    .then(({ total, rows }) => {
      pagination.itemCount = total
      tableData.value = rows
    })
    .catch(() => {})
    .finally(() => {
      loading.value = false
    })
}
search()

// 新增/修改岗位
const showDialog = ref(false)
const postData = ref({})
const addPost = async (post = {}) => {
  showDialog.value = true
  // 这里不是为了复制原因，是需要改变不同的对象地址，达到子组件可以监听对象的变化
  postData.value = JSON.parse(JSON.stringify(post))
}
// 删除岗位
const delPost = (post = {}) => {
  $dialog.confirm({
    content: '确认删除岗位 [' + post.postName + '] ？',
    confirm() {
      $message.loading('正在删除中', {
        duration: 0,
        key: 'delPost',
      })
      deletePost(post.postId)
        .then(() => {
          $message.success('删除成功')
          search()
        })
        .catch(() => {
          $message.error('删除失败')
        })
        .finally(() => {
          $message.destroy('delPost')
        })
    },
  })
}

// 表头数据
const columns = createColumns({
  addPost,
  delPost,
})
// 下载表格
const download = () => {
  downloadFile('system/post/export', { ...getParams() }, `post_${new Date().getTime()}.xlsx`)
}
</script>
