<template>
  <template v-modal-move="showUserModal">
    <n-modal
      v-model:show="showUserModal"
      class="modal-move"
      :title="title"
      :style="{ width: '50%' }"
      preset="card"
      :mask-closable="false"
    >
      <!-- 内容 -->
      <n-form
        ref="userFormRef"
        :model="userForm"
        label-placement="left"
        require-mark-placement="left"
        label-width="80"
      >
        <n-row>
          <n-col :span="12">
            <n-form-item label="昵称" path="nickName" :rule="required">
              <n-input
                v-model:value="userForm.nickName"
                placeholder="请输入昵称"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="归属部门" path="deptId" :rule="{ ...required, type: 'number' }">
              <n-tree-select
                v-model:value="userForm.deptId"
                :options="deptOptions"
                key-field="id"
                clearable
                placeholder="请选择归属部门"
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="手机号码" path="phonenumber" :rule="phoneRequired">
              <n-input
                v-model:value="userForm.phonenumber"
                placeholder="请输入手机号码"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="邮箱" path="email" :rule="emailRequired">
              <n-input
                v-model:value="userForm.email"
                placeholder="请输入邮箱"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
        </n-row>

        <!-- 新建的时候才会显示 -->
        <n-row v-if="userForm.userId === undefined">
          <n-col :span="12">
            <n-form-item label="用户名称" path="userName" :rule="required">
              <n-input
                v-model:value="userForm.userName"
                placeholder="请输入用户名称"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="用户密码" path="password" :rule="[required, ...pwdRequired]">
              <n-input
                v-model:value="userForm.password"
                placeholder="请输入用户密码"
                :allow-input="trim"
                type="password"
                show-password-on="mousedown"
                clearable
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="性别" path="sex" :rule="required">
              <n-select
                v-model:value="userForm.sex"
                :options="sexOptions"
                placeholder="请选择性别"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="状态" path="status" :rule="required">
              <n-radio-group v-model:value="userForm.status">
                <n-space>
                  <n-radio value="0">启用</n-radio>
                  <n-radio value="1">停用</n-radio>
                </n-space>
              </n-radio-group>
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="岗位" path="postIds">
              <n-select
                v-model:value="userForm.postIds"
                :options="postOptions"
                multiple
                clearable
                label-field="postName"
                value-field="postId"
                placeholder="请选择岗位"
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="角色" path="roleIds">
              <n-select
                v-model:value="userForm.roleIds"
                :options="roleOptions"
                multiple
                clearable
                label-field="roleName"
                value-field="roleId"
                placeholder="请选择角色"
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-form-item label="备注" path="remark">
          <n-input
            v-model:value="userForm.remark"
            type="textarea"
            placeholder="请输入内容"
            clearable
          />
        </n-form-item>
      </n-form>
      <!-- 底部按钮 -->
      <template #footer>
        <footer class="flex justify-end">
          <n-button @click="showUserModal = false">取消</n-button>
          <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmUser">
            确定
          </n-button>
        </footer>
      </template>
    </n-modal>
  </template>
</template>
<script setup>
import { sexOptions, required, pwdRequired, emailRequired, phoneRequired } from '@/store/options'
import { trim } from '@/composables'
import { getDeptTree } from '@/api/dept'
import { getUserTake, updateUserInfo } from '@/api/user'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showUserModal = ref(false)
const userForm = ref({})
const loading = ref(false)

// 获取岗位列表和角色列表
let postOptions = reactive([])
let roleOptions = reactive([])
const getTake = (userId) => {
  getUserTake(userId)
    .then(({ roles = [], posts = [], postIds = [], roleIds = [] }) => {
      userForm.value.postIds = postIds
      userForm.value.roleIds = roleIds
      postOptions = posts.map((data) => {
        data.disabled = data.status === '1'
        return data
      })
      roleOptions = roles.map((data) => {
        data.disabled = data.status === '1'
        return data
      })
    })
    .catch(() => {})
}
watch(
  () => props.show,
  (value) => {
    showUserModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showUserModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    userForm.value = data
    getTake(userForm.value.userId)
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  return userForm.value.userId !== undefined ? '编辑用户' : '新增用户'
})
// 获取部门列表
const deptOptions = ref([])
const getDeptList = () => {
  getDeptTree()
    .then(({ data = [] }) => {
      deptOptions.value = data
    })
    .catch(() => {})
}
getDeptList()

// 确定修改或者添加用户
const userFormRef = ref(null)
const confirmUser = () => {
  userFormRef.value
    ?.validate((error) => {
      if (!error) {
        loading.value = true
        updateUserInfo(userForm.value)
          .then(() => {
            showUserModal.value = false
            $message.success('操作成功')
            emits('confirm')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}
</script>
