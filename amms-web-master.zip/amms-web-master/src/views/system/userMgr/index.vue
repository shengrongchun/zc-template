<template>
  <CommonPage>
    <template #action>
      <div class="flex">
        <n-button ghost type="primary" class="ml-20" @click="reset">
          <i class="i-zc:rotate-ccw mr-4" />
          重置
        </n-button>
        <n-button class="ml-20" type="primary" @click="search">
          <i class="i-zc:search mr-4" />
          查询
        </n-button>
        <n-button type="primary" class="ml-20" @click="addUser()">
          <i class="i-zc:plus mr-4" />
          新建
        </n-button>
        <n-button type="default" class="ml-20" @click="download">
          <i class="i-zc:download mr-4" />
          导出
        </n-button>
      </div>
    </template>
    <div class="flex">
      <div class="w-16% p-r-10px">
        <zcCompanys :selectedKey="selectedKey" @selected="selectedDep"></zcCompanys>
      </div>
      <div class="w-84%">
        <PageHeader>
          <PageHeaderItem label="用户名" :label-width="70">
            <n-input
              v-model:value="searchForm.userName"
              type="text"
              placeholder="用户名模糊查询"
              clearable
            />
          </PageHeaderItem>

          <PageHeaderItem label="手机号码" :label-width="70">
            <n-input
              v-model:value="searchForm.phonenumber"
              type="text"
              placeholder="手机号模糊查询"
              clearable
            />
          </PageHeaderItem>

          <PageHeaderItem label="创建时间" :label-width="70" :contentWidth="270">
            <n-date-picker
              type="daterange"
              v-model:value="searchForm.dateRange"
              :is-date-disabled="disablePreviousDate"
              clearable
            />
          </PageHeaderItem>

          <PageHeaderItem label="状态" :label-width="70">
            <n-select v-model:value="searchForm.status" clearable :options="statusOptions" />
          </PageHeaderItem>
        </PageHeader>
        <!-- 表格加分页 -->
        <n-data-table
          :remote="true"
          :loading="loading"
          :columns="columns"
          :data="tableData"
          :pagination="pagination"
        />
      </div>
    </div>
    <!-- 新增/修改 -->
    <AddDialog
      :show="showDialog"
      :data="userData"
      @confirm="search"
      @close="showDialog = false"
    ></AddDialog>
    <!-- 分配角色 -->
    <AddRole
      :show="showRoleDialog"
      :data="userRoleData"
      @confirm="search"
      @close="showRoleDialog = false"
    ></AddRole>
  </CommonPage>
</template>
<script setup>
import { getUserList } from '@/api/user'
import { deleteUser, resetUserPassword } from '@/api/user'
import { statusOptions } from '@/store/options'
import { getPagination } from '@/composables'
import { isArray, formatDate, downloadFile } from '@/utils'
import { createColumns } from './options'
import AddDialog from './addDialog.vue'
import AddRole from './addRole.vue'
import { NInput } from 'naive-ui'
import { h } from 'vue'

// 表格数据
const tableData = ref([])
// 加载loading
const loading = ref(false)
// n-tree 默认选中项目
const selectedKey = ref()
// 分页数据
const pagination = getPagination({
  change() {
    search()
  },
})

// 初始化form数据
const form = {
  userName: null, // 用户名称
  phonenumber: null, // 手机号码
  status: null, // 状态
  dateRange: null, // 创建时间
  deptId: null,
}
const searchForm = ref(JSON.parse(JSON.stringify(form)))

// 重置查询条件
const reset = () => {
  searchForm.value = JSON.parse(JSON.stringify(form))
  pagination.page = 1
  pagination.pageSize = 10
  selectedKey.value = null
  search()
}

// 获取查询参数
const getParams = () => {
  const { page: pageNum, pageSize } = pagination
  const { dateRange, userName, phonenumber, status, deptId } = searchForm.value
  const params = {
    userName,
    phonenumber,
    status,
    deptId,
    pageNum,
    pageSize,
  }
  if (isArray(dateRange)) {
    params.params = {
      beginTime: formatDate(dateRange[0]),
      endTime: formatDate(dateRange[1]),
    }
  }
  return params
}

// 查询数据
const search = () => {
  loading.value = true
  const params = getParams()
  getUserList(params)
    .then(({ total, rows }) => {
      pagination.itemCount = total
      tableData.value = rows.map((row) => {
        row.deptName = row?.dept?.deptName
        return row
      })
    })
    .catch(() => {})
    .finally(() => {
      loading.value = false
    })
}
search()

// 选中的部门
const selectedDep = (dep) => {
  searchForm.value.deptId = dep.id
  selectedKey.value = dep.id
  search()
}

// 只能选之前的时间
const disablePreviousDate = (ts) => {
  return ts > Date.now()
}

// 新增/修改用户
const showDialog = ref(false)
let userData = reactive({})
// 增加更新用户
const addUser = (user = {}) => {
  showDialog.value = true
  // 这里不是为了复制原因，是需要改变不同的对象地址，达到子组件可以监听对象的变化
  userData = JSON.parse(JSON.stringify(user))
}
// 删除用户
const delUser = (user = {}) => {
  $dialog.confirm({
    content: '确认删除？',
    confirm() {
      $message.loading('正在删除中', {
        duration: 0,
        key: 'delUser',
      })
      deleteUser(user.userId)
        .then(() => {
          $message.success('删除成功')
          search()
        })
        .catch(() => {
          $message.error('删除失败')
        })
        .finally(() => {
          $message.destroy('delUser')
        })
    },
  })
}
// 用户重置密码
const resetUserPwd = (user) => {
  const pwd = ref()
  $dialog.info({
    title: '重置密码',
    content: () =>
      h(NInput, {
        value: pwd.value,
        type: 'password',
        placeholder: '请输入新密码',
        showPasswordOn: 'mousedown',
        onUpdateValue: (val) => {
          pwd.value = val
        },
      }),
    positiveText: '确定',
    onPositiveClick: async () => {
      if (!pwd.value) {
        $message.error('请输入新密码')
        return false
      }
      const { code } = await resetUserPassword(user.userId, pwd.value)
      if (code === 200) {
        $message.success('重置成功')
        return true
      }
      $message.error('重置失败')
      return false
    },
  })
}
// 分配角色
const showRoleDialog = ref(false)
let userRoleData = reactive({})
const handleAuthRole = (user) => {
  showRoleDialog.value = true
  userRoleData = JSON.parse(JSON.stringify(user))
}
// 表头数据
const columns = createColumns({
  addUser,
  delUser,
  resetUserPwd,
  handleAuthRole,
})

// 下载表格
const download = () => {
  downloadFile('system/user/export', { ...getParams() }, `user_${new Date().getTime()}.xlsx`)
}
</script>
