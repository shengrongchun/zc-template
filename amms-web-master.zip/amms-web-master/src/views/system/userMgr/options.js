import { NButton, NTag } from 'naive-ui'
import { sexOptions, statusOptions } from '@/store/options'

export const createColumns = ({ addUser, delUser, resetUserPwd, handleAuthRole }) => {
  return [
    {
      title: '用户编号',
      key: 'userId',
    },
    {
      title: '用户名称',
      key: 'userName',
    },
    {
      title: '用户昵称',
      key: 'nickName',
    },
    {
      title: '部门',
      key: 'deptName',
    },
    {
      title: '手机号码',
      key: 'phonenumber',
    },
    {
      title: '性别',
      key: 'sex',
      render(row) {
        return h(
          NTag,
          {
            type: row.sex === '0' ? 'primary' : 'error',
            bordered: false,
          },
          { default: () => sexOptions.find(({ value }) => value === row.sex).label }
        )
      },
    },
    {
      title: '状态',
      key: 'status',
      render(row) {
        return h(
          NTag,
          {
            type: row.status === '0' ? 'success' : 'error',
            bordered: false,
          },
          { default: () => statusOptions.find(({ value }) => value === row.status).label }
        )
      },
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'actions',
      render(row) {
        if (row.userId === 1) {
          return
        }
        return [
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              onClick: () => addUser(row),
            },
            { default: () => '编辑' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'error',
              style: {
                marginLeft: '10px',
              },
              onClick: () => delUser(row),
            },
            { default: () => '删除' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'warning',
              style: {
                marginLeft: '10px',
              },
              onClick: () => resetUserPwd(row),
            },
            { default: () => '重置密码' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'success',
              style: {
                marginLeft: '10px',
              },
              onClick: () => handleAuthRole(row),
            },
            { default: () => '分配角色' }
          ),
        ]
      },
    },
  ]
}

// 分配角色
export const createRoleColumns = () => {
  return [
    {
      type: 'selection',
    },
    {
      title: '角色编号',
      key: 'roleId',
    },
    {
      title: '角色名称',
      key: 'roleName',
    },
    {
      title: '权限字符',
      key: 'roleKey',
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
  ]
}
