<template>
  <template v-modal-move="showRoleModal">
    <n-modal
      v-model:show="showRoleModal"
      class="modal-move"
      :title="title"
      :style="{ width: '50%' }"
      preset="card"
      :mask-closable="false"
    >
      <!-- 表格加分页 -->
      <n-data-table
        :columns="columns"
        :data="tableData"
        :pagination="pagination"
        :row-key="(row) => row.roleId"
        :checked-row-keys="checkedRowKeys"
        :on-update:checked-row-keys="updateCheckedRowKeys"
      />
      <!-- 底部按钮 -->
      <template #footer>
        <footer class="flex justify-end">
          <n-button @click="showRoleModal = false">取消</n-button>
          <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmRole">
            确定
          </n-button>
        </footer>
      </template>
    </n-modal>
  </template>
</template>
<script setup>
import { getPagination } from '@/composables'
import { getAuthRoleList, updateAuthRoleList } from '@/api/role'
import { createRoleColumns } from './options'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showRoleModal = ref(false)
const userData = ref({})
const tableData = ref([])
const checkedRowKeys = ref([])
const updateCheckedRowKeys = (data) => {
  checkedRowKeys.value = data
}
// 查询
const search = () => {
  const { userId } = userData.value
  if (userId !== undefined) {
    getAuthRoleList(userId)
      .then((data) => {
        tableData.value = data.roles || []
        checkedRowKeys.value = []
        // 回显选中的值
        tableData.value.forEach((row) => {
          if (row.flag) {
            checkedRowKeys.value.push(row.roleId)
          }
        })
      })
      .catch(() => {})
  }
}
watch(
  () => props.show,
  (value) => {
    showRoleModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showRoleModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    userData.value = data
    search()
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  const { userName, nickName } = userData.value
  return '角色分配 [ 名称：' + userName + ' 、 昵称：' + nickName + ' ]'
})
// 分页数据
const pagination = getPagination()
const columns = createRoleColumns()
// 确认
const loading = ref(false)
const confirmRole = () => {
  loading.value = true
  updateAuthRoleList({ userId: userData?.value?.userId, roleIds: checkedRowKeys.value.join(',') })
    .then(() => {
      $message.success('分配成功')
      showRoleModal.value = false
      emits('confirm')
    })
    .catch(() => {
      $message.error('分配失败')
    })
    .finally(() => {
      loading.value = false
    })
}
</script>
