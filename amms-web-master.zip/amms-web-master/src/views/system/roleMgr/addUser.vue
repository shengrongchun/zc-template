<template>
  <template v-modal-move="showRoleModal">
    <n-modal
      v-model:show="showRoleModal"
      class="modal-move"
      :title="title"
      :style="{ width: '73%' }"
      preset="card"
      :mask-closable="false"
    >
      <PageHeader>
        <PageHeaderItem label="用户名称" :label-width="70">
          <n-input
            v-model:value="searchForm.userName"
            type="text"
            placeholder="用户名称模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="手机号码" :label-width="70">
          <n-input
            v-model:value="searchForm.phonenumber"
            type="text"
            placeholder="手机号码模糊查询"
            clearable
          />
        </PageHeaderItem>
        <PageHeaderItem label="状态" :label-width="43">
          <n-select v-model:value="searchForm.status" :options="locationStatusOptions" />
        </PageHeaderItem>
        <div>
          <n-button ghost type="primary" class="ml-20" @click="reset">
            <i class="i-zc:rotate-ccw mr-4" />
            重置
          </n-button>
          <n-button class="ml-20" type="primary" @click="search">
            <i class="i-zc:search mr-4" />
            查询
          </n-button>
          <n-button
            ghost
            type="primary"
            class="ml-20"
            @click="setLocation()"
            :disabled="!checkedRowKeys.length"
          >
            <i class="i-zc:rotate-ccw mr-4" />
            {{ searchForm.status === '0' ? '批量取消分配' : '批量分配' }}
          </n-button>
        </div>
      </PageHeader>
      <!-- 表格加分页 -->
      <n-data-table
        :loading="loading"
        :columns="columns"
        :data="tableData"
        :pagination="pagination"
        :row-key="(row) => row.userId"
        :checked-row-keys="checkedRowKeys"
        :on-update:checked-row-keys="updateCheckedRowKeys"
      />
    </n-modal>
  </template>
</template>
<script setup>
import { getPagination } from '@/composables'
import { allocatedUserList, unallocatedUserList, setLocationUser } from '@/api/role'
import { createUserColumns, locationStatusOptions } from './options'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showRoleModal = ref(false)
const roleData = ref({})
const tableData = ref([])
const checkedRowKeys = ref([])
const updateCheckedRowKeys = (data) => {
  checkedRowKeys.value = data
}
// 初始化form数据
const form = {
  userName: null, // 用户名称
  phonenumber: null, // 手机号码
  status: '0', // 0 已分配， 1未分配
}
// 查询
const searchForm = ref(JSON.parse(JSON.stringify(form)))
const columns = ref([])
const search = () => {
  checkedRowKeys.value = []
  columns.value = createUserColumns({ status: searchForm.value.status, setLocation })
  const { roleId } = roleData.value
  if (roleId !== undefined) {
    const method = searchForm.value.status === '0' ? allocatedUserList : unallocatedUserList
    method({ ...searchForm.value, roleId })
      .then(({ rows, total }) => {
        tableData.value = rows
        pagination.itemCount = total
      })
      .catch(() => {})
  }
}
// 确认
const loading = ref(false)
// 分配action
const setLocation = (user) => {
  loading.value = true
  const { status } = searchForm.value
  const userIds = (user ? [user.userId] : checkedRowKeys.value).join(',')
  const params = {
    status,
    userIds,
    roleId: roleData.value.roleId,
  }
  setLocationUser(params)
    .then(() => {
      search()
      $message.success('操作成功')
    })
    .catch(() => {
      $message.error('操作失败')
    })
    .finally(() => {
      loading.value = false
    })
}
// 重置查询条件
const reset = () => {
  searchForm.value = JSON.parse(JSON.stringify(form))
  pagination.page = 1
  pagination.pageSize = 10
  search()
}
watch(
  () => props.show,
  (value) => {
    showRoleModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showRoleModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    roleData.value = data
    search()
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  const { roleName, roleKey } = roleData.value
  return '用户分配 [ 角色名称：' + roleName + ' 、 权限字符：' + roleKey + ' ]'
})
// 分页数据
const pagination = getPagination()
</script>
