<template>
  <template v-modal-move="showUserModal">
    <n-modal
      v-model:show="showUserModal"
      class="modal-move"
      :title="title"
      :style="{ width: '50%' }"
      preset="card"
      :mask-closable="false"
    >
      <!-- 内容 -->
      <n-form
        ref="userFormRef"
        :model="userForm"
        label-placement="left"
        require-mark-placement="left"
        label-width="80"
      >
        <n-row>
          <n-col :span="12">
            <n-form-item label="角色名称" path="roleName" :rule="required">
              <n-input
                v-model:value="userForm.roleName"
                placeholder="请输入角色名称"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item
              label="权限字符"
              title="控制器中定义的权限字符，如：@PreAuthorize(`@ss.hasRole('admin')`)"
              path="roleKey"
              :rule="required"
            >
              <n-input
                v-model:value="userForm.roleKey"
                placeholder="请输入权限字符"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="角色顺序" path="roleSort" :rule="{ ...required, type: 'number' }">
              <n-input-number v-model:value="userForm.roleSort" clearable class="w-100%" />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="状态" path="status" :rule="required">
              <n-radio-group v-model:value="userForm.status">
                <n-space>
                  <n-radio value="0">启用</n-radio>
                  <n-radio value="1">停用</n-radio>
                </n-space>
              </n-radio-group>
            </n-form-item>
          </n-col>
        </n-row>
        <!-- 菜单权限 -->
        <n-form-item label="菜单权限">
          <div class="w-100% m-t-6px">
            <n-checkbox-group v-model:value="menuTypes">
              <n-space item-style="display: flex;">
                <n-checkbox value="0" label="展开/折叠" />
                <n-checkbox value="1" label="父子联动" />
              </n-space>
            </n-checkbox-group>
            <n-tree
              block-line
              expand-on-click
              checkable
              multiple
              show-line
              :selectable="false"
              check-strategy="child"
              :data="menuList"
              :checked-keys="userForm.menuIds"
              :cascade="menuTypes.includes('1')"
              :default-expand-all="menuTypes.includes('0')"
              :on-update:checked-keys="updateCheckedKeys"
            />
          </div>
        </n-form-item>

        <n-form-item label="备注" path="remark">
          <n-input
            v-model:value="userForm.remark"
            type="textarea"
            placeholder="请输入内容"
            clearable
          />
        </n-form-item>
      </n-form>
      <!-- 底部按钮 -->
      <template #footer>
        <footer class="flex justify-end">
          <n-button @click="showUserModal = false">取消</n-button>
          <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmUser">
            确定
          </n-button>
        </footer>
      </template>
    </n-modal>
  </template>
</template>
<script setup>
import { required } from '@/store/options'
import { trim } from '@/composables'
import { updateRole } from '@/api/role'
import { routes } from '@/router/routes'
import { getRouteMenuList } from '@/utils/common'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showUserModal = ref(false)
const userForm = ref({})
const loading = ref(false)

watch(
  () => props.show,
  (value) => {
    showUserModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showUserModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    userForm.value = data
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  return userForm.value.roleId !== undefined ? '编辑角色' : '新增角色'
})
// 菜单
const menuTypes = ref(['0', '1'])
const menuList = getRouteMenuList(routes)
const updateCheckedKeys = (list) => {
  userForm.value.menuIds = list
}

// 确定修改或者添加角色
const userFormRef = ref(null)
const confirmUser = () => {
  userFormRef.value
    ?.validate((error) => {
      if (!error) {
        loading.value = true
        updateRole(userForm.value)
          .then(() => {
            showUserModal.value = false
            $message.success('操作成功')
            emits('confirm')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}
</script>
