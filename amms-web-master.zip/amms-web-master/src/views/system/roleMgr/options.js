import { NButton, NTag } from 'naive-ui'
import { statusOptions } from '@/store/options'

export const createColumns = ({ addRole, delRole, setDataScope, handleAuthUser }) => {
  return [
    {
      title: '角色编号',
      key: 'roleId',
    },
    {
      title: '角色名称',
      key: 'roleName',
    },
    {
      title: '权限字符',
      key: 'roleKey',
    },
    {
      title: '显示顺序',
      key: 'roleSort',
    },
    {
      title: '状态',
      key: 'status',
      render(row) {
        return h(
          NTag,
          {
            type: row.status === '0' ? 'success' : 'error',
            bordered: false,
          },
          { default: () => statusOptions.find(({ value }) => value === row.status).label }
        )
      },
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'actions',
      render(row) {
        if (row.roleId === 1) {
          return
        }
        return [
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              onClick: () => addRole(row),
            },
            { default: () => '编辑' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'error',
              style: {
                marginLeft: '10px',
              },
              onClick: () => delRole(row),
            },
            { default: () => '删除' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'warning',
              style: {
                marginLeft: '10px',
              },
              onClick: () => setDataScope(row),
            },
            { default: () => '数据权限' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'success',
              style: {
                marginLeft: '10px',
              },
              onClick: () => handleAuthUser(row),
            },
            { default: () => '分配用户' }
          ),
        ]
      },
    },
  ]
}

// 分配用户
export const createUserColumns = ({ status, setLocation }) => {
  return [
    {
      type: 'selection',
    },
    {
      title: '用户编号',
      key: 'userId',
    },
    {
      title: '用户名称',
      key: 'userName',
    },
    {
      title: '用户昵称',
      key: 'nickName',
    },
    {
      title: '手机号码',
      key: 'phonenumber',
    },
    {
      title: '状态',
      key: 'status',
      render(row) {
        return h(
          NTag,
          {
            type: row.status === '0' ? 'success' : 'error',
            bordered: false,
          },
          { default: () => statusOptions.find(({ value }) => value === row.status).label }
        )
      },
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'actions',
      render(row) {
        return [
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              onClick: () => setLocation(row),
            },
            { default: () => (status === '0' ? '取消分配' : '分配') }
          ),
        ]
      },
    },
  ]
}
// 数据范围选项
export const dataScopeOptions = [
  { value: '1', label: '全部数据权限' },
  { value: '2', label: '自定数据权限' },
  { value: '3', label: '本部门数据权限' },
  { value: '4', label: '本部门及以下数据权限' },
  { value: '5', label: '仅本人数据权限' },
]
// 状态：已分配/未分配
export const locationStatusOptions = [
  { value: '0', label: '已分配' },
  { value: '1', label: '未分配' },
]
