<template>
  <CommonPage>
    <template #action>
      <div class="flex">
        <n-button ghost type="primary" class="ml-20" @click="reset">
          <i class="i-zc:rotate-ccw mr-4" />
          重置
        </n-button>
        <n-button class="ml-20" type="primary" @click="search">
          <i class="i-zc:search mr-4" />
          查询
        </n-button>
        <n-button type="primary" class="ml-20" @click="addRole()">
          <i class="i-zc:plus mr-4" />
          新建
        </n-button>
        <n-button type="default" class="ml-20" @click="download">
          <i class="i-zc:download mr-4" />
          导出
        </n-button>
      </div>
    </template>
    <div>
      <PageHeader>
        <PageHeaderItem label="角色名" :label-width="70">
          <n-input
            v-model:value="searchForm.roleName"
            type="text"
            placeholder="角色名模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="权限字符" :label-width="70">
          <n-input
            v-model:value="searchForm.roleKey"
            type="text"
            placeholder="权限字符模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="创建时间" :label-width="70" :contentWidth="270">
          <n-date-picker
            type="daterange"
            v-model:value="searchForm.dateRange"
            :is-date-disabled="disablePreviousDate"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="状态" :label-width="70">
          <n-select v-model:value="searchForm.status" clearable :options="statusOptions" />
        </PageHeaderItem>
      </PageHeader>
      <!-- 表格加分页 -->
      <n-data-table
        :remote="true"
        :loading="loading"
        :columns="columns"
        :data="tableData"
        :pagination="pagination"
      />
    </div>
    <!-- 新增/修改 -->
    <AddDialog
      :show="showDialog"
      :data="roleData"
      @confirm="search"
      @close="showDialog = false"
    ></AddDialog>
    <!-- 数据权限 -->
    <DataScope
      :show="showDataScopeDialog"
      :data="roleData"
      @confirm="search"
      @close="showDataScopeDialog = false"
    ></DataScope>
    <!-- 分配用户 -->
    <AddUser
      :show="showUserDialog"
      :data="userData"
      @confirm="search"
      @close="showUserDialog = false"
    ></AddUser>
  </CommonPage>
</template>
<script setup>
import { getRoleList, deleteRole, getDeptTreeSelect } from '@/api/role'
import { statusOptions } from '@/store/options'
import { getPagination } from '@/composables'
import { isArray, formatDate, downloadFile } from '@/utils'
import { createColumns } from './options'
import AddDialog from './addDialog.vue'
import DataScope from './dataScope.vue'
import AddUser from './addUser.vue'

// 表格数据
const tableData = ref([])
// 加载loading
const loading = ref(false)
// 分页数据
const pagination = getPagination({
  change() {
    search()
  },
})
// 初始化form数据
const form = {
  roleName: null, // 角色名称
  roleKey: null, // 权限字符
  status: null, // 状态
  dateRange: null, // 创建时间
}
const searchForm = ref(JSON.parse(JSON.stringify(form)))
// 重置查询条件
const reset = () => {
  searchForm.value = JSON.parse(JSON.stringify(form))
  pagination.page = 1
  pagination.pageSize = 10
  search()
}
// 获取查询参数
const getParams = () => {
  const { page: pageNum, pageSize } = pagination
  const { dateRange, roleName, roleKey, status } = searchForm.value
  const params = {
    roleName,
    roleKey,
    status,
    pageNum,
    pageSize,
  }
  if (isArray(dateRange)) {
    params.params = {
      beginTime: formatDate(dateRange[0]),
      endTime: formatDate(dateRange[1]),
    }
  }
  return params
}
// 查询数据
const search = () => {
  loading.value = true
  const params = getParams()
  getRoleList(params)
    .then(({ total, rows }) => {
      pagination.itemCount = total
      tableData.value = rows
    })
    .catch(() => {})
    .finally(() => {
      loading.value = false
    })
}
search()

// 只能选之前的时间
const disablePreviousDate = (ts) => {
  return ts > Date.now()
}

// 新增/修改角色
const showDialog = ref(false)
const roleData = ref({})
const addRole = async (role = {}) => {
  showDialog.value = true
  // 这里不是为了复制原因，是需要改变不同的对象地址，达到子组件可以监听对象的变化
  roleData.value = JSON.parse(JSON.stringify(role))
}
// 删除角色
const delRole = (role = {}) => {
  $dialog.confirm({
    content: '确认删除角色 [' + role.roleName + '] ？',
    confirm() {
      $message.loading('正在删除中', {
        duration: 0,
        key: 'delRole',
      })
      deleteRole(role.roleId)
        .then(() => {
          $message.success('删除成功')
          search()
        })
        .catch(() => {
          $message.error('删除失败')
        })
        .finally(() => {
          $message.destroy('delRole')
        })
    },
  })
}
// 分配数据权限
const showDataScopeDialog = ref(false)
const setDataScope = async (role) => {
  showDataScopeDialog.value = true
  let deptIds = null
  if (role.roleId !== undefined) {
    const { checkedKeys = [] } = await getDeptTreeSelect(role.roleId)
    deptIds = checkedKeys
  }
  // 这里不是为了复制原因，是需要改变不同的对象地址，达到子组件可以监听对象的变化
  roleData.value = JSON.parse(JSON.stringify({ ...role, deptIds }))
}
// 分配用户
const showUserDialog = ref(false)
const userData = ref({})
const handleAuthUser = (role) => {
  showUserDialog.value = true
  userData.value = JSON.parse(JSON.stringify(role))
}
// 表头数据
const columns = createColumns({
  addRole,
  delRole,
  setDataScope,
  handleAuthUser,
})

// 下载表格
const download = () => {
  downloadFile('system/role/export', { ...getParams() }, `roles_${new Date().getTime()}.xlsx`)
}
</script>
