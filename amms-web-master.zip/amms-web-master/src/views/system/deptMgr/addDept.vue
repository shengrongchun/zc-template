<template>
  <template v-modal-move="showUserModal">
    <n-modal
      v-model:show="showUserModal"
      class="modal-move"
      :title="title"
      :style="{ width: '50%' }"
      preset="card"
      :mask-closable="false"
    >
      <!-- 内容 -->
      <n-form
        ref="userFormRef"
        :model="userForm"
        label-placement="left"
        require-mark-placement="left"
        label-width="80"
      >
        <n-row>
          <n-col :span="12" v-if="userForm.parentId !== 0">
            <n-form-item label="上级部门" path="parentId" :rule="{ ...required, type: 'number' }">
              <n-tree-select
                v-model:value="userForm.parentId"
                :options="deptOptions"
                key-field="id"
                clearable
                placeholder="请选择上级部门"
              />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="部门名称" path="deptName" :rule="required">
              <n-input
                v-model:value="userForm.deptName"
                placeholder="请输入部门名称"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="部门顺序" path="orderNum" :rule="{ ...required, type: 'number' }">
              <n-input-number v-model:value="userForm.orderNum" clearable class="w-100%" />
            </n-form-item>
          </n-col>
        </n-row>

        <n-row>
          <n-col :span="12">
            <n-form-item label="负责人" path="leader">
              <n-input
                v-model:value="userForm.leader"
                placeholder="请输入负责人"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="手机号码" path="phone" :rule="phoneRequired">
              <n-input
                v-model:value="userForm.phone"
                placeholder="请输入手机号码"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
        </n-row>
        <n-row>
          <n-col :span="12">
            <n-form-item label="邮箱" path="email" :rule="emailRequired">
              <n-input
                v-model:value="userForm.email"
                placeholder="请输入邮箱"
                :allow-input="trim"
                clearable
              />
            </n-form-item>
          </n-col>
          <n-col :span="12">
            <n-form-item label="状态" path="status" :rule="required">
              <n-radio-group v-model:value="userForm.status">
                <n-space>
                  <n-radio value="0">启用</n-radio>
                  <n-radio value="1">停用</n-radio>
                </n-space>
              </n-radio-group>
            </n-form-item>
          </n-col>
        </n-row>
      </n-form>
      <!-- 底部按钮 -->
      <template #footer>
        <footer class="flex justify-end">
          <n-button @click="showUserModal = false">取消</n-button>
          <n-button type="primary" class="ml-20" :disabled="loading" @click="confirmUser">
            确定
          </n-button>
        </footer>
      </template>
    </n-modal>
  </template>
</template>
<script setup>
import { required, phoneRequired, emailRequired } from '@/store/options'
import { trim } from '@/composables'
import { getDeptTree, addDept, updateDept } from '@/api/dept'

const emits = defineEmits(['close', 'confirm'])
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: {},
  },
})
const showUserModal = ref(false)
const userForm = ref({})
const loading = ref(false)

watch(
  () => props.show,
  (value) => {
    showUserModal.value = value
  },
  {
    immediate: true,
  }
)
watch(
  () => showUserModal.value,
  (value) => {
    if (!value) {
      emits('close')
    }
  }
)
watch(
  () => props.data,
  (data = {}) => {
    userForm.value = data
  },
  {
    immediate: true,
  }
)
const title = computed(() => {
  return userForm.value.type === 'add' ? '新增部门' : '修改部门'
})
// 获取部门列表
const deptOptions = ref([])
const getDeptList = () => {
  getDeptTree()
    .then(({ data = [] }) => {
      deptOptions.value = data
    })
    .catch(() => {})
}
getDeptList()

// 确定修改或者添加部门
const userFormRef = ref(null)
const confirmUser = () => {
  userFormRef.value
    ?.validate((error) => {
      if (!error) {
        loading.value = true
        const { type } = userForm.value
        const methodName = type === 'add' ? addDept : updateDept
        methodName(userForm.value)
          .then(() => {
            showUserModal.value = false
            $message.success('操作成功')
            emits('confirm')
          })
          .finally(() => {
            loading.value = false
          })
          .catch(() => {})
      }
    })
    .catch(() => {})
}
</script>
