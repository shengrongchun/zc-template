<template>
  <CommonPage>
    <template #action>
      <div class="flex">
        <n-button ghost type="primary" class="ml-20" @click="reset">
          <i class="i-zc:rotate-ccw mr-4" />
          重置
        </n-button>
        <n-button class="ml-20" type="primary" @click="search">
          <i class="i-zc:search mr-4" />
          查询
        </n-button>
        <n-button type="primary" class="ml-20" @click="addDept('add')">
          <i class="i-zc:plus mr-4" />
          新建
        </n-button>
        <n-button
          type="default"
          class="ml-20"
          @click="switchOpen"
          :disabled="!!searchForm.deptName"
        >
          <i class="i-zc:co mr-4" />
          展开/折叠
        </n-button>
      </div>
    </template>
    <div>
      <PageHeader>
        <PageHeaderItem label="部门名称" :label-width="70">
          <n-input
            v-model:value="searchForm.deptName"
            type="text"
            placeholder="部门名称模糊查询"
            clearable
          />
        </PageHeaderItem>

        <PageHeaderItem label="状态" :label-width="70">
          <n-select v-model:value="searchForm.status" clearable :options="statusOptions" />
        </PageHeaderItem>
      </PageHeader>
      <!-- 表格加分页 -->
      <n-data-table
        :remote="true"
        :loading="loading"
        :columns="columns"
        :data="tableData"
        :row-key="(row) => row.deptId"
        :expanded-row-keys="expandKeys"
        :on-update:expanded-row-keys="updateExpandRowKeys"
      />
    </div>
    <!-- 新增/修改 -->
    <AddDialog
      :show="showDialog"
      :data="deptData"
      @confirm="search"
      @close="showDialog = false"
    ></AddDialog>
  </CommonPage>
</template>
<script setup>
import { getDeptList, deleteDept } from '@/api/dept'
import { statusOptions } from '@/store/options'
import { createColumns, listToTree } from './options'
import AddDialog from './addDept.vue'

// 表格数据
const tableData = ref([])
// 加载loading
const loading = ref(false)
// 初始化form数据
const form = {
  deptName: null, // 部门名称
  status: null, // 状态
}
const searchForm = ref(JSON.parse(JSON.stringify(form)))
// 重置查询条件
const reset = () => {
  searchForm.value = JSON.parse(JSON.stringify(form))
  search()
}
// 获取查询参数
const getParams = () => {
  return { ...searchForm.value }
}
// 获取父节点的key列表
const parentKeys = new Set()
// 展开节点列表
const expandKeys = ref([])
const switchOpen = () => {
  expandKeys.value = expandKeys.value.length === parentKeys.size ? [] : Array.from(parentKeys)
}
const updateExpandRowKeys = (keys) => {
  expandKeys.value = keys
}
// 查询数据
const search = () => {
  loading.value = true
  const params = getParams()
  getDeptList(params)
    .then(({ data }) => {
      parentKeys.clear()
      tableData.value = !!searchForm.value.deptName ? data : listToTree(data, parentKeys)
    })
    .catch(() => {})
    .finally(() => {
      loading.value = false
    })
}
search()
// 新增/修改部门
const showDialog = ref(false)
const deptData = ref({})
const addDept = async (type, dept = {}) => {
  showDialog.value = true
  // 这里不是为了复制原因，是需要改变不同的对象地址，达到子组件可以监听对象的变化
  let obj = { type }
  if (type === 'add') {
    obj.parentId = dept.deptId
  } else {
    obj = { ...dept, type }
  }
  deptData.value = JSON.parse(JSON.stringify(obj))
}
// 删除部门
const delDept = (dept = {}) => {
  $dialog.confirm({
    content: '确认删除部门 [' + dept.deptName + '] ？',
    confirm() {
      $message.loading('正在删除中', {
        duration: 0,
        key: 'delPost',
      })
      deleteDept(dept.deptId)
        .then(() => {
          $message.success('删除成功')
          search()
        })
        .catch(() => {
          $message.error('删除失败')
        })
        .finally(() => {
          $message.destroy('delPost')
        })
    },
  })
}

// 表头数据
const columns = createColumns({
  addDept,
  delDept,
})
</script>
