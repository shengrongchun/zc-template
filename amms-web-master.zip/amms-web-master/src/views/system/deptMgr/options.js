import { NButton, NTag } from 'naive-ui'
import { statusOptions } from '@/store/options'

export const createColumns = ({ addDept, delDept }) => {
  return [
    {
      title: '部门名称',
      key: 'deptName',
    },
    {
      title: '排序',
      key: 'orderNum',
    },
    {
      title: '状态',
      key: 'status',
      render(row) {
        return h(
          NTag,
          {
            type: row.status === '0' ? 'success' : 'error',
            bordered: false,
          },
          { default: () => statusOptions.find(({ value }) => value === row.status).label }
        )
      },
    },
    {
      title: '创建时间',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'actions',
      render(row) {
        return [
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              onClick: () => addDept('edit', row),
            },
            { default: () => '编辑' }
          ),
          h(
            NButton,
            {
              size: 'small',
              type: 'primary',
              style: {
                marginLeft: '10px',
              },
              onClick: () => addDept('add', row),
            },
            { default: () => '新增' }
          ),
          row.parentId === 0
            ? null
            : h(
                NButton,
                {
                  size: 'small',
                  type: 'error',
                  style: {
                    marginLeft: '10px',
                  },
                  onClick: () => delDept(row),
                },
                { default: () => '删除' }
              ),
        ]
      },
    },
  ]
}

// 将列表转换为树形结构
export const listToTree = (list, parentKeys = new Set()) => {
  const map = {}
  const tree = []

  list.forEach((item) => {
    map[item.deptId] = { ...item, children: [] }
  })
  list.forEach((item) => {
    if (item.parentId) {
      parentKeys.add(item.parentId)
      map[item.parentId]?.children?.push(map[item.deptId])
    } else {
      tree.push(map[item.deptId])
    }
  })

  return tree
}
