import { getUser } from '@/api/user'

export async function getUserInfo() {
  const res = await getUser()
  const {
    userId: id,
    userName,
    avatar,
    nickName,
    sex: gender,
    email,
    roles,
    phonenumber,
  } = res.user || {}
  const roleName = roles.map(({ roleName }) => roleName).join(',')

  return {
    id,
    userName, // 用户名称
    phonenumber, // 手机号码
    avatar, // 头像
    nickName, // 昵称
    gender, // 性别
    email, // 邮箱
    roleName,
    roles,
  }
}
