import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'

export function setupStore(app) {
  const pinia = createPinia()
  // 增加数据持久化功能，具体看模块中 persist 配置
  pinia.use(piniaPluginPersistedstate)
  app.use(pinia)
}

export * from './modules'
