// 状态下拉列表
export const statusOptions = [
  { label: '启用', value: '0' },
  { label: '停用', value: '1' },
]
// 性别列表
export const sexOptions = [
  { label: '男', value: '0' },
  { label: '女', value: '1' },
]

// 表单校验规则
export const required = { required: true, message: '此为必填项', trigger: ['blur', 'change'] }

// 密码
export const pwdRequired = [
  { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' },
  /* eslint-disable */
  { pattern: /^[^<>"'|\\]+$/, message: '不能包含非法字符：< > " \' \\ |', trigger: 'blur' },
]

// 邮箱
export const emailRequired = [
  {
    pattern: /^\w+(-+.\w+)*@\w+(-.\w+)*.\w+(-.\w+)*$/,
    message: '请输入正确格式的邮箱',
    trigger: 'blur',
  },
]

// 手机号
export const phoneRequired = [
  {
    pattern:
      /^((\+|00)86)?1((3[\d])|(4[5,6,7,9])|(5[0-3,5-9])|(6[5-7])|(7[0-8])|(8[\d])|(9[1,8,9]))\d{8}$/,
    message: '请输入正确格式的手机号',
    trigger: 'blur',
  },
]
