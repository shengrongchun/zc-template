/**
 * userStore: 用户信息
 */
import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', {
  state: () => ({
    userInfo: null,
    avatarStyle: {},
  }),
  getters: {
    userName() {
      return this.userInfo?.userName
    },
    nickName() {
      return this.userInfo?.nickName
    },
    avatar() {
      return this.userInfo?.avatar
    },
    phonenumber() {
      return this.userInfo?.phonenumber || {}
    },
    roleName() {
      return this.userInfo?.roleName
    },
  },
  actions: {
    setUser(user) {
      this.userInfo = user
    },
    setAvatarStyle(avatarStyle) {
      this.avatarStyle = avatarStyle
    },
    resetUser() {
      this.$reset()
    },
  },
})
