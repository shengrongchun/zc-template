/**
 * permissionStore: 创建路由，菜单
 */
import { defineStore } from 'pinia'

export const usePermissionStore = defineStore('permission', {
  state: () => ({
    accessRoutes: [], // 经过权限控制后最终的路由
    routes: [], // 全局路由
    menus: [], // 经过权限控制后最终的菜单
    passKeys: [],
  }),
  actions: {
    setPermissions(routes, passKeys) {
      this.passKeys = passKeys
      this.routes = routes
      this.generateRoutes(routes)
      this.generateMenus(routes)
    },
    // 菜单控制在这里处理
    generateMenus(routes, menuItem) {
      const menus = []
      for (const route of routes) {
        if (route.type !== 'NO_MENU') {
          const menuItem = {
            label: route.meta.title,
            key: route.name,
            path: route.path,
            originPath: route.meta.originPath,
            icon: () => h('i', { class: `${route.meta.icon}?mask text-16` }),
            order: route.order ?? 0,
          }
          // 超级管理员
          if (!this.passKeys) {
            if (route?.children?.length) {
              this.generateMenus(route.children, menuItem)
            }
            menus.push(menuItem)
            continue
          }
          // 如果有子节点
          if (route?.children?.length) {
            const subMenus = this.generateMenus(route.children, menuItem)
            if (subMenus.length) {
              menus.push(menuItem)
            }
            continue
          }
          // 如果是叶子结点
          if (this.passKeys.includes(route.meta.key)) {
            menus.push(menuItem)
          }
        }
      }
      //
      menus.sort((a, b) => a.order - b.order)
      if (menuItem) {
        menuItem.children = menus
      } else {
        this.menus = menus
      }
      return menus
    },
    // 如果有权限控制路由，在这里处理
    generateRoutes(routes) {
      for (const route of routes) {
        if (
          route.path &&
          route.component &&
          (!this.passKeys || this.passKeys.includes(route.meta.key))
        ) {
          this.accessRoutes.push(route)
        }
        if (route?.children?.length) {
          this.generateRoutes(route.children)
        }
      }
    },
    resetPermission() {
      this.$reset()
    },
  },
})
