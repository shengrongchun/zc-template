/**
 * appStore: 菜单栏的收缩，主题切换与设置，布局切换
 */
import { defineStore } from 'pinia'
// @vueuse/core提供了很多常见方法：https://vueuse.org/core/useDark/#demo
import { useDark } from '@vueuse/core'
import { defaultLayout, naiveThemeOverrides } from '@/settings'
export const useAppStore = defineStore('app', {
  state: () => ({
    collapsed: false,
    isDark: useDark(),
    layout: defaultLayout,
    naiveThemeOverrides,
  }),
  actions: {
    switchCollapsed() {
      this.collapsed = !this.collapsed
    },
    setCollapsed(b) {
      this.collapsed = b
    },
    toggleDark() {
      this.isDark = !this.isDark
    },
    setLayout(v) {
      this.layout = v
    },
  },
  persist: {
    // 持久化属性
    paths: ['collapsed', 'naiveThemeOverrides'],
    // 持久化存储方式
    storage: sessionStorage,
  },
})
