import '@/styles/reset.css'
import '@/styles/global.scss'
import 'uno.css'

import { createApp } from 'vue'
import App from './App.vue'
import { setupRouter } from './router'
import { setupStore } from './store'
// 常用方法和 axios
import { setupNaiveDiscreteApi } from './utils'
// 创建指令，如按钮控制显示指令
import { setupDirectives } from './directives'

async function bootstrap() {
  const app = createApp(App)
  setupStore(app)
  setupNaiveDiscreteApi()
  setupDirectives(app)
  await setupRouter(app)
  app.mount('#app')
}
bootstrap()
