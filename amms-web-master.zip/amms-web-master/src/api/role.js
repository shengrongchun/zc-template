import { request } from '@/utils'

// 查询角色列表
export const getRoleList = (params) => {
  return request({
    url: '/system/role/list',
    method: 'get',
    params,
  })
}
// 获取用户分配角色列表
export const getAuthRoleList = (userId) => {
  return request({
    url: '/system/user/authRole/' + userId,
    method: 'get',
  })
}
// 保存授权角色
export const updateAuthRoleList = (params) => {
  return request({
    url: '/system/user/authRole',
    method: 'put',
    params,
  })
}
// 新增修改角色
export const updateRole = (data) => {
  return request({
    url: '/system/role',
    method: data.roleId !== undefined ? 'put' : 'post',
    data,
  })
}
// 获取角色对应的菜单权限
export const getRoleMenuIds = (roleId) => {
  return request({
    url: '/system/menu/roleMenuTreeselect/' + roleId,
    method: 'get',
  })
}
// 根据角色ID查询部门树结构
export const getDeptTreeSelect = (roleId) => {
  return request({
    url: '/system/role/deptTree/' + roleId,
    method: 'get',
  })
}
// 删除角色
export const deleteRole = (roleId) => {
  return request({
    url: '/system/role/' + roleId,
    method: 'delete',
  })
}
// 角色数据权限
export const setDataScope = (data) => {
  return request({
    url: '/system/role/dataScope',
    method: 'put',
    data,
  })
}
// 查询角色已授权用户列表
export const allocatedUserList = (params) => {
  return request({
    url: '/system/role/authUser/allocatedList',
    method: 'get',
    params,
  })
}
// 查询角色未授权用户列表
export const unallocatedUserList = (params) => {
  return request({
    url: '/system/role/authUser/unallocatedList',
    method: 'get',
    params,
  })
}
// 分配操作
export const setLocationUser = ({ status, userIds, roleId }) => {
  const url = status === '0' ? '/system/role/authUser/cancelAll' : '/system/role/authUser/selectAll'
  return request({
    url,
    method: 'put',
    params: {
      userIds,
      roleId,
    },
  })
}
