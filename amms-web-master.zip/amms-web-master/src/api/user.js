import { request } from '@/utils'
import { parseStrEmpty } from '@/utils/common'

// 获取用户信息
export const getUser = () => request.get('/system/user/getInfo')

// 更新用户个人信息
export const updateProfile = (data) => request.put(`/system/user/profile`, data)

// 更新用户密码
export const changePassword = (data) =>
  request.put(
    `/system/user/profile/updatePwd?oldPassword=${data.oldPassword}&newPassword=${data.newPassword}`
  )

// 查询用户岗位和角色信息
export const getUserTake = (userId) => request.get('/system/user/' + parseStrEmpty(userId))

// 新增或者更新用户信息
export const updateUserInfo = (data) => {
  return request({
    url: '/system/user',
    method: data.userId !== undefined ? 'put' : 'post',
    data,
  })
}

// 删除用户
export const deleteUser = (userId) => {
  return request({
    url: '/system/user/' + userId,
    method: 'delete',
  })
}

// 用户密码重置
export const resetUserPassword = (userId, password) => {
  const data = {
    userId,
    password,
  }
  return request({
    url: '/system/user/resetPwd',
    method: 'put',
    data: data,
  })
}

// 获取用户列表信息
export const getUserList = (params) =>
  request.get('/system/user/list', {
    params,
  })
