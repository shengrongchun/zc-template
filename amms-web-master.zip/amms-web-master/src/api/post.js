import { request } from '@/utils'

// 查询岗位列表
export const getPostList = (params) => {
  return request({
    url: '/system/post/list',
    method: 'get',
    params,
  })
}
// 修改/新增岗位
export function updatePost(data) {
  return request({
    url: '/system/post',
    method: data.postId !== undefined ? 'put' : 'post',
    data,
  })
}
// 删除岗位
export const deletePost = (postId) => {
  return request({
    url: '/system/post/' + postId,
    method: 'delete',
  })
}
