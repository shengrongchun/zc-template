import { request } from '@/utils'

// 获取验证码图片
export const getCodeImg = (data) => request.get('/code', data, { noNeedToken: true })

// 登录
export const login = (data) => request.post('/auth/login', data, { noNeedToken: true })

// 登出
export const logout = () => request.delete('/auth/logout')
