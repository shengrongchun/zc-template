module.exports = {
  ignorePatterns: ['node_modules/*', 'dist/*', 'public/*', 'package.json', 'package-lock.json'],
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    ecmaFeatures: {
      jsx: true,
    },
  },
  env: {
    node: true,
    commonjs: true,
    browser: true,
    es2021: true,
  },
  extends: [
    'eslint:recommended',
    // eslint-plugin-vue vue语法配置
    'plugin:vue/vue3-recommended',
    // eslint-plugin-prettier 把Prettier配置成ESLint的一个插件，让其当做一个linter规则来运行
    // 避免与 prettier 冲突 eslint-config-prettier 会关闭ESLint中有关代码格式化的配置
    'plugin:prettier/recommended',
    '.eslint-global-variables.json',
    '@unocss',
  ],
  rules: {
    'prettier/prettier': 'error', //  在eslint中运行prettier，并启用该插件提供的规则
    'no-unused-vars': ['error', { args: 'after-used' }],
    'vue/valid-template-root': 'error',
    'vue/no-multiple-template-root': 'off',
    'vue/multi-word-component-names': 'off',
    'no-console': 'error',
    'vue/no-lone-template': 'off',
  },
}
